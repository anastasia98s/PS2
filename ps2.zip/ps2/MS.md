Meilensteinplan
Meilenstein 1: Buch von Jonas Freiknecht 
•	Beschreibung: Beschaffung des Buchs KI-Sprachassistenten von Jonas Freiknecht zur Vorbereitung und Informationssammlung.
•	Ziele:
o	Buch erwerben oder leihen.
o	Relevante Kapitel für das Projekt identifizieren und inhaltlich sichten.
Meilenstein 2: Teamleiter auswählen
•	Beschreibung: Auswahl eines Teamleiters, der das Projekt koordiniert und die Verantwortung übernimmt.
•	Ziele:
o	Kandidaten für die Rolle auswählen.
o	Gespräche und Abstimmungen durchführen.
o	Teamleiter benennen und kommunizieren.
Meilenstein 3: Versionsverwaltung über GitHub einrichten
•	Beschreibung: Einrichtung eines GitHub-Repositories für die Versionsverwaltung und Dokumentation des Projekts.
•	Ziele:
o	GitHub Repository erstellen.
Meilenstein 4: Aufteilung in Projektteams
•	Beschreibung: Einteilung des Projektteams in kleinere Teams, die an spezifischen Aufgaben arbeiten.
•	Ziele:
o	Klarheit über Rollen und Verantwortlichkeiten schaffen.
